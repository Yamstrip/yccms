exports .dom = {
	node: [
		//UI资源
		{
			conf: {
				
			},
		},
		//页面
		{
			
		}
	],
	'ui': true,
	style: {
		padding: '30px 0 30px 0'
	}
}
exports .require = [
	'/css/简洁UI'
]
exports .head = [
	{
		tag: 'meta',
		name: "theme-color",
		content: 'RGB(71,80,89)'
	},
	{
		tag: 'meta',
		charset: "utf-8",
		name: "viewport",
		content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
	}
]
exports .require = [
	'/css/简洁UI',
	'/font/细英语',
	'/js/wave.js',
	'/js/响应式.js'
]
exports .style = {
	body: {
		style: {
			'font-family': 'E1',
			'background-color': 'RGB(110,136,230)'
		}
	}
}
exports .str = [
	{
		tag: 'script',
		src: 'https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js'
	}
]
//INT
exports .metarequire = [
	'lib/ui.js'
]