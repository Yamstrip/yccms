exports .type = 'html'
exports .public = false
exports .limit = 1
//exports .user = [ 'Admin' ]
exports .nopass = '/ser/log'