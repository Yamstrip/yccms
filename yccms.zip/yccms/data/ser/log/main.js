exports .dom = {
	node: [
		//登录的
		{
			tag: 'h1',
			text: '登录',
			style: {
				'text-align': 'center',
				'margin': '60px 0 35px 0'
			}
		},
		//输入
		{
			'card-1-p': true,
			text: 'User'
		},
		{
			tag: 'input',
			id: 'user',
			'card-1-input': true,
			placeholder: '填写用户名'
		},
		//输入1
		{
			'card-1-p': true,
			text: 'Password'
		},
		{
			tag: 'input',
			id: 'password',
			type: 'password',
			'card-1-input': true,
			placeholder: '填写密码'
		},
		//按钮
		{
			'card-1-button': true,
			text: 'SIGN IN',
			wave: 'true',
			style: {
				color: 'white',
				'box-Shadow': '0 0 30px 0.1px RGBa(97,131,255,0.5)',
				'margin': '40px 0 40px 0',
				'background-color': 'RGB(97,131,255)'
			},
			onclick: function ( cl ) {
				
			}
		}
	],
	style: {
		'transition-Duration': '0.5s'
	},
	'fp-c': '0.4 0.9'
}

exports .code = function ( ser , cl ) {
	//用户，SER
	ser .on ( 'log' , function ( data ) {
		if ( ! cl .user [ 'Admin' ] ) {
			if ( data .账号 == ser .账号 && data .密码 == ser .密码 ) {
				cl .emit ( 'log-成功' )
				cl .user [ 'Admin' ] = 1
			} else {
				cl .emit ( 'log-错误' )
			}
		} else {
			cl .emit ( 'log-已经登录' )
		}
	} )
	cl .on ( 'log-成功' , function ( ) {
		alert ( '登录成功' )
		location .href = '/public/index'
	} )
	cl .on ( 'log-已经登录' , function ( ) {
		alert ( '已经登录' )
		location .href = '/public/index'
	} )
	cl .on ( 'log-错误' , function ( ) {
		alert ( '账号或密码错误' )
	} )
}

exports .str = [
	{
		tag: 'script',
		src: 'https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js'
	}
]

exports .require = [
	'/css/简洁UI',
	'/font/细英语',
	'/js/wave.js',
	'/js/响应式.js'
]
exports .style = {
	body: {
		style: {
			'font-family': 'E1'
		}
	}
}

exports .end = [
	{
		tag: 'script',
		text: 'wave .load ( )'
	}
]
exports .head = [
	{
		tag: 'meta',
		charset: "utf-8",
		name: "viewport",
		content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
	}
]
