exports .code = 'res'
exports .public = false
exports .type = 'font-family'
exports .name = 'E1'
exports .rawindex = 'ttf'
exports .src = '/main.ttf'