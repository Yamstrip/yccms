exports .dom = {
	node: [
		{
			tag: 'h1',
			style: {
				color: 'white',
				'text-align': 'center'
			},
			text: 'Welcome YCCMS'
		},
		{
			'export': [ 'card' , 'card onclick onclick' ],
			'onclick': 'location.href=\'admin\'',
			'card-1': true,
			style: {
				'export': 'card color background-color',
				'border-Radius': '5px',
				'background-color': 'rgb(164, 229, 237)',
				'color': 'white'
			},
			'fp-c': '0.4 1',
			node: [
				{
					'style': {
						'width': '70px',
						'height': '70px',
						'display': 'flex',
						'align-items': 'center',
						'justify-content': 'center',
						'margin-left': 'calc(50% - 35px)',
						'text-align': 'center',
						'Border-Radius': '130px',
						'font-size': '30px',
						'margin-top': '20px',
						'margin-Bottom': '10px',
						'color': 'rgb(164, 229, 237)',
						'export': 'card color color',
						'background-color': 'white'
					},
					node: [
						{
							export: 'card title text',
							tag: 'p',
							text: 'M'
						}
					]
				},
				{
					export: 'card text text',
					'tag': 'h1',
					'text': 'Manager',
					'style': {
						'text-Align': 'center',
						'margin': '5px 0 0 0'
					}
				},
				{
					'export': 'card data text',
					'tag': 'h3',
					'style': {
						width: '70%',
						'margin-left': '15%',
						'text-Align': 'center'
					},
					'text': '您可以访问127.0.0.1:8080/admin,根据开启服务器设置的账户和密码登录,来管理网站'
				}
			]
		},
		{
			load: {
				name: 'card',
				data: {
					color: 'RGB(252,109,212)',
					title: 'F',
					text: 'Free Program',
					data: '这是一个免费的框架,虽然谈不上性能,但是不妨打赏两杯咖啡,让我有更多时间修这个'
				}
			}
		},
		{
			load: {
				name: 'card',
				data: {
					color: 'RGB(232,184,107)',
					title: 'V',
					text: 'Visualization',
					data: '加上一个可视化的网站编辑器,和逻辑编辑器,小白也会用'
				}
			}
		},
		{
			load: {
				name: 'card',
				data: {
					onclick: 'location.href=\'https://jq.qq.com/?_wv=1027&k=gNh2sogz\'',
					color: 'RGB(242,126,126)',
					title: 'C',
					text: 'Chat group',
					data: '欢迎加入官方聊天群\nYmstrip'
				}
			}
		}
	],
	style: {
		padding: '30px 0 30px 0'
	}
}
exports .require = [
	'/css/简洁UI'
]
exports .head = [
	{
		tag: 'meta',
		name: "theme-color",
		content: 'RGB(71,80,89)'
	},
	{
		tag: 'meta',
		charset: "utf-8",
		name: "viewport",
		content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
	}
]
exports .require = [
	'/css/简洁UI',
	'/font/细英语',
	'/js/wave.js',
	'/js/响应式.js'
]
exports .style = {
	body: {
		style: {
			'font-family': 'E1',
			'background-color': 'RGB(110,136,230)'
		}
	}
}
exports .str = [
	{
		tag: 'script',
		src: 'https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js'
	}
]