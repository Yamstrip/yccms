exports .dom = {
	node: [
		{
			'text': '404',
			'style': {
				'font-size': '60px',
				'text-Align': 'center',
				'padding': '50px 0 30px 0',
				'color': 'white'
			}
		},
		{
			'text': '当前页面暂时无法访问',
			'style': {
				'font-size': '20px',
				'text-align': 'center',
				'color': 'white'
			}
		},
		{
			'onclick': 'location.href=\'/\'',
			'class': 'G',
			'text': '首页',
			'style': {
				'font-size': '30px',
				'color': 'RGB(89,120,255)',
				'width': '40%',
				'margin-left': '30%',
				'background-color': 'white',
				'text-Align': 'center',
				'Border-Radius': '25px',
				'margin-top': '35px',
				'padding': '15px 0 15px 0',
				'transition-Duration': '0.5s'
			}
		}
	],
	style: {
		'height': '100%'
	}
}
exports .style = {
	body: {
		style: {
			'padding': '0 0 0 0',
			'margin': '0 0 0 0',
			'background-color': 'RGBa(255,61,119,0.8)'
		}
	},
	'.G': {
		hover: {
			'color': 'RGBa(100,130,255)',
			'box-Shadow': '0 0 5px 0.5px RGB(89,120,255)'
		}
	}
}
exports .head = [
	{
		tag: 'meta',
		charset: "utf-8",
		name: "viewport",
		content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
	},
	{
		tag: 'meta',
		name: "theme-color",
		content: 'RGBa(255,61,119,0.8)'
	}
]