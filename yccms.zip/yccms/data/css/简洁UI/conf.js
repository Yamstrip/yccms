exports .code = 'require'
exports .type = 'css'
exports .public = false
exports .limit = 1