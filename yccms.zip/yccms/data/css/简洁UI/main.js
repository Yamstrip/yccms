exports [ '[card-1]' ] = {
	style: {
		"margin": "25px 0 25px 0",
		"padding": "25px 20px 25px 20px",
		"width": "calc(90% - 40px)",
		"margin-left": "calc(5% )",
		"box-Shadow": "0 0 5px 0.5px rgba(0,0,0,0.05)",
		"transition-Duration": "0.5s"
	},
	"hover": {
		"opacity": 0.8,
		"box-Shadow": "0 0 5px 1px rgba(0,0,0,0.15)"
	}
}

exports [ '[card-1-input]' ] = {
	style: {
		'width': '95%',
		'outline':'none',
		'padding-left': '15px',
		'height': '50px',
		'font-size': '20px',
		'font-Family': 'E1',
		'margin': '17px 0 17px 2.5%',
		'Border': '1px solid RGB(193,201,214)',
		'Border-Radius': '2px',
		'Color': 'rgba(0,0,0,0.2)',
		'transition-Duration': '0.5s'
	},
	hover: {
		'color': 'rgba(0,0,0,0.6)',
		'Border': '1px solid RGB(71,145,255)',
		'box-Shadow': '0 0 5px 1px rgba(0,0,0,0.1)'
	}
}
exports [ '[card-1-p]' ] = {
	style: {
		'margin-left': '2.5%',
		'font-size': '18px',
		'color': 'rgba(0,0,0,0.5)'
	}
}
exports [ '[card-1-button]' ] = {
	style: {
		'padding': '15px 0 15px 0',
		'font-size':'17px',
		'text-Align': 'center',
		'Border-Radius': '2.5px',
		'width': '70%',
		'margin-left': '15%'
	}
}
exports [ '[wave=true]' ] = {
	style: {
		overflow: 'hidden',
		position: 'relative',
		transition: '1s'
	}
}

exports [ '.wave' ] = {
	style: {
		position: 'absolute',
		width: '10px',
		height: '10px',
		'transition-duration': '0.5s',
		'background-color': 'rgb(156, 192, 255)',
		opacity: '0.3',
		'border-radius': '9999px'
	}
}
exports [ 'body' ] = {
	style: {
		margin: '0 0 0 0',
		padding: '0 0 0 0'
	}
}