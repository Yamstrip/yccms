/*
API文档
------
这个分为 服务器 , 前端
服务端通过require 启动
-------
*/
let yc = require ( 'yc+' )
yc .require ( require ( 'yccms' ) )
let web = yc .open ( 'yccms' )
//生成服务器对象
let Server = web .start ( {
	
	/*[key: 密匙],
	[cret: 证书],
	[port: 端口]
	*/
} )
Server .request ( function ( data ) {
	//事件
	/*
	{
		req,
		res,
		ip,
		end: 结束,
		endjson: 返回JSON结束连接,
		href: 跳转目录,//只有请求路径不同时才会跳转
		enderror: 结束请求,
		data: JSON的url参数
	}
	*/
	console.log( data )
} )
Server .error ( function ( e ) {
	/*
	{
		type: 错误类型
		href: 路径跳转
	}
	*/
} )

/*
目录结构
目录分为文件夹和文件,文件直接请求,文件夹获取里面的conf.js与main.js

conf.js的API:
非必要 exports .name = 'xxx' 一些资源的名称，如字体
非必要exports .src = 'xxx' 请求路径更改,默认/main.js
非必要 exports .user = {
  xxx: 等级
} 权限组
非必要 exports .limit = Number 一秒请求最大数量
非必要 exports .nopass = '跳转url' 如果有exports .user , 权限组不通过就跳转路径
非必要 exports .type = '资源类型'
非必要 exports .public = Boolean 是否外网ip能访问该资源
非必要 exports .raw = 自定义Content-Type,默认是自动查询的
*/

/*
main.js资源
exports .dom = {
	节点,和exports .dom写法一样
	node: [
	{...},
	{...}
	....
	],
	[tag: 标签名称],
	attr: value , 参数: 值,会生成 < attr="value">,
	[text: 强制更改节点],
	style: {
		color: ....
		....: ...
		样式属性
	},
	onclick: function ( user ) {
		//USER是client的对象
		user .on ( xxx , function ( data ) {
			//data .emit 也可以,但是on只能在user
		} )
		开启一个监听
		user .emit ( xxx , data )
		给服务器请求一个对象
	},
	export: 'value' 如果单纯export: 'value' , 导出一个类,名称叫'value'
	export: 'value index index1',
	如果export里面有3个，则代表类 'value' 的 index 下标 对应的资源是当前JSON树的 index1下标
	load: {
		name: 'value', 导入export导出的类,
		data: {
			index: value
			...
			这里的index就是export导出里面的index 对应的 index1
		}
	},
	这样起到了写一个模板,然后简单设置几个参数就可以不用重复一堆JSON,
}
//请求资源,如css,字体之类的,图片在这里请求没什么用
exports .require = [
/ser/index..
url,
url
...

]
//请求Build时的资源,该资源只能在Build页面时运行
exports .buildrequire = [
/ser/build.js,
....
]
//在html头部加入dom
exports .head = [
{
	dom ...如
	tag:'meta',
	name: ...
}
]
//在导入exports .require 资源之前,在body插入dom
exports .str = [
{
	dom
}
]
//在导入exports .require 资源之后，在body插入dom
exports .end = [
{
	...
}
]
*/
//Code代码
exports .code = function ( Server , Client ) {
	//服务器与前端快速请求
	Server .on ( 名称 , ( req , res ) => {
		req= JSON数据,
		res= {
			ip,
			end: ( json ), //返回数据
			href: ( 路径 ) //返回路径
		}
	} )
	//生成Client与Server的Websocket连接,
	Server .ws ( function ( ws ) {
		ws .on ( 'xxx' ,function ( req , res ) {
			req = 数据
			res= {
				ip,
				end: ( json , 回调 ), //返回数据,
				emit: ( '名称' , 数据 , 回调 ),//传递
				href: ( 路径 ) //跳转
			}
		} )
		//ws可以直接emit,而直接Server只能在on事件里面emit
		ws .emit ( '名称' , { } , 回调 , 和 on 的 一样 )
	} )
	Client .on ( '名称' , function ( data , res ) {
		//data是数据
		//res是浏览器端包装的对象
		res= {
			call: function ( data , r => Clienton函数返回一样的 ) { },//返回,
			emit: function ( 名称 , 数据 , r )
		}
		这里面可以执行浏览器代码如.$ ,document ....
	} )
}
//全局样式
exports .style = {
	名称: {
		hover: {
			color: ...,
			...: ...
		}
		,
		style: {
			...
		}
		style是直接 名称: { ... },
		hover其他,或自定义,就是 名称:hover { ... }
	}
	资源文件如果是文件夹,也这样
}
/*
没修完，以后慢慢肝