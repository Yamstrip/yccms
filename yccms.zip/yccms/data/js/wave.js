let wave = { }
wave .do = function ( dom ) {
	if ( ! dom .get ( ) [ 0 ] .iswave ) {
	let d = true
	let isb = false
	if ( dom .css ( 'background-color' ) == 'rgba(0, 0, 0, 0)') isb = true
	let as = [  ]
	let str = function ( e ) {
		let f = e .changedTouches
		if ( d == true && isb == true ) dom .css ( 'background-color', 'rgba(214, 229, 255,0.3)' )
		for ( let i = 0; i < f .length; i ++ ) {
			let s = f [ i ]
			as = [ s .pageX , s .pageY ]
		}
	}
	let lift = function ( e ) {
	if ( d == true ) {
		let f = $ ( "<div class='wave'></div>" )
		dom .append ( f )
		//获取点击时的坐标
		let x = as [ 0 ]
		let y = as [ 1 ]
		//获取按钮的坐标
		let ofs = dom .offset ( )
		let moveX = ofs .left
		let moveY = ofs .top
		//获取按钮宽度
		let btnWidth = dom .width ( )
		//设置点击后波浪样式
		let waveDiv = f .get ( ) [ 0 ]
		waveDiv.style.borderRadius = 60;
		waveDiv.style.width = 200+'px'; 
		waveDiv.style.left = x-moveX-5+'px';
		waveDiv.style.marginLeft = -100+'px';
		waveDiv.style.height = 200+'px';
		waveDiv.style.top = y-moveY-5+'px';
		waveDiv.style.backgroundColor = 'rgba(0,0,0,0)'
		waveDiv.style.marginTop = -100+'px';
		//定时删除波浪
		if ( d == true && isb == true ) dom .css ( 'background-color', 'rgba(0,0,0,0.00)' )
		setTimeout(function(){
			waveDiv.remove();
		},1000);
		//不可以执行一次点击效果
		d = false;
	} else {
		return false;
	}
	}
	
	dom .bind ( 'touchmove' , function ( e ) {
		lift ( e )
	} )
	dom .bind ( 'mousemove' , function ( e ) {
		lift ( e )
	} )
	
	dom .bind ( 'touchstart' , str )
	dom .bind ( 'mousestart' , str )
	
	dom .bind ( 'touchend' , function ( e ) {
		lift ( e )
		d = true
	} )
	dom .bind ( 'mouseend' , function ( e ) {
		lift ( e )
		d = true
	} )
	
	
	dom .get ( ) [ 0 ] .iswave = true
	} 
}
wave .load = function ( ) {
	$ ( '[wave=true]' ) .get ( ) .forEach ( s => {
		wave .do ( $ ( s ) )
	} )
}