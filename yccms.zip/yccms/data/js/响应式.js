!( function ( d ) {
	window .响应式 = { }
	let state = 'mc'
	if (!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) {
		state = 'pc'
	}
	//屏幕高宽
	let h = document .body .clientHeight
	let w = document .body .clientWidth
	//PC伸缩
	function pc ( code ) {
		$ ( '[' + code + ']' ) .each ( ( i , d ) => {
			d = $ ( d )
			let r = d .attr ( code ) .split ( ' ' )
			if ( r [ 0 ] < 0 || r [ 0 ] > 1 || ( Number ( r [ 0 ] ) + '' == 'NaN' ) ) {
				r [ 0 ] = 0.5
			}
			if ( r [ 1 ] < 1 || r [ 1 ] > 1 || ( Number ( r [ 1 ] ) + '' == 'NaN' ) ) {
				r [ 1 ] = 0.5
			}
			r [ 0 ] = Number ( r [ 0 ] )
			r [ 1 ] = Number ( r [ 1 ] )
			let ws = d .parent ( ) .width ( )
			let hs = d .height ( )
			//伸缩
			d .css ( {
				width: ws * r [ 0 ],
				marginLeft: ( ws - ws * r [ 0 ] ) / 2,
				height: hs * r [ 1 ],
				marginTop: ( hs - hs * r [ 1 ] ) / 2,
			} )
		} )
	}
	try {
	if ( state == 'pc' ) {
		pc ( 'fp-c' )
	} else {
		pc ( 'fm-c' )
	}
	} catch ( e ) {
	}

} ) ( {} ) 