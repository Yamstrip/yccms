exports .name = 'yccms'
exports .main = function ( yc , on , ret , emit , retcall ) {
	//初始化
	let obj = { }
	obj .start = false
	obj .path = 'data/yccms'
	//函数
	ret ( 'setpath' , function ( path ) {
		if ( yc .isdir ( path ) ) {
			obj .path = path
		} else {
			throw path + ' 不是一个有效路径'
		}
	} )
	ret ( 'dirname' , function ( d ) {
		obj .dirname = d
		if ( ! yc .isdir ( d + '/data' ) ) {
			//构建仓库
			yc .copydir ( __dirname + '/data' , d + '/data' )
			yc .c ( 's' , 'yccms仓库初始化完成' )
		}
		obj .dirname += '/data'
	} )
	ret ( 'start' , function ( conf ) {
		if ( ! obj .dirname ) {
			throw '请 obj .dirname ( path ) 设置路径'
		}
		return yc .call ( function ( call1 ) {
			if ( ! conf ) conf = { }
			obj .port = 8080
			obj .key = false
			obj .obj = { }
			obj .obj .ip = { }
			//赋值
			for ( let i in conf ) {
				obj [ i ] = conf [ i ]
			}
			//服务器请求
			if ( conf .key && conf .cert ) {
			//https
				obj .http = require ( 'https' ) .createServer ( {
					key: obj .key,
					cert: obj .cert
				} , req_d ) .listen ( obj .port )
			} else {
				//没有https
				obj .http = require ( 'http' ) .createServer ( req_d ) .listen ( obj .port )
			}
			//REQ
			function req_d ( req , res ) {
				if ( ! obj .stop ) {
					try {
						emit ( 'http' , {
							req,
							res,
							error: obj .error,
							dirname: obj .dirname,
							obj: obj .obj,
							request: obj .request
						} )
					} catch ( e ) {
						yc .c ( 'e' , 'yccms请求的时候出了点错误:' + e )
						console .log ( e )
						res .writeHead ( 500 )
						res .end ( )
					}
				} else {
					res .end ( )
				}
			}
			//暂停
			call1 .ret ( 'stop' , function ( time ) {
				obj .stop = true
				if ( time ) {
					setTimeout ( function ( ) {
						delete obj .stop
					} , time )
				}
			} )
			//ERROR
			call1 .ret ( 'error' , function ( d ) {
				obj .error = d
			} )
			//继续
			call1 .ret ( 'continue' , function ( ) {
				delete obj .stop
			} )
			//ON函数
			call1 .ret ( 'request' , function ( d ) {
				obj .request = d
			} )
			yc .c ( 's' , 'yccms服务器开启成功,端口: ' + obj .port + ',输入 yccms stop 可暂停')
		} )
	} )
	//SHELL
	yc .shell .setcmd ( 'yccms' , '网站' , function ( d , c ) {
		switch ( d [ 1 ] ) {
			case 'help':
				c ( [
					'yccms help' , ' 帮助',
					'yccms stop [time]' , ' 暂停',
					'yccms start' , ' 取消暂停',
					'yccms exit' , ' 关闭服务端口',
					'yccms run [port]' , ' 开启服务器端口'
				] )
			break
			case 'stop':
				if ( ! obj .stop ) {
					obj .stop = true
					if ( d [ 2 ] !== '' && Number ( d [ 2 ] ) + '' !== 'NaN' ) {
						setTimeout ( function ( ) {
							delete obj .stop
							yc .c ( 's' , 'yccms继续了' )
						}, Number ( d [ 2 ] ) )
					}
					yc .c ( 's' , 'yccms停止成功' )
				} else {
					yc .c ( 'e' , 'yccms已经停止了' )
				}
			break
			case 'start':
				if ( obj .stop ) {
					delete obj .stop
					yc .c ( 's' , 'yccms开始运行' )
				} else {
					yc .c ( 'e' , 'yccms正常运行中' )
				}
			break
			case 'exit':
				if ( obj .http ) {
					obj .http .close ( )
					yc .c ( 's' , 'yccms关闭成功' )
					delete obj .http
				} else {
					yc .c ( 'e' , 'yccms未开启' )
				}
			break
			case 'run':
				if ( ! obj .http ) {
					let port = 8080
					if ( d [ 2 ] !== '' && Number ( d [ 2 ] ) + '' !== 'NaN' ) {
						port = Number ( d [ 2 ] )
					}
					retcall ( 'start' , {
						port
					} )
				} else {
					yc .c ( 'e' , 'yccms已经存在服务器' )
				}
			break
			default:
				yc .c ( 'e' , '未知命令 ' + d [ 1 ] + ' 输入 yccms help 查询帮助' )
			break
		}
	} )
	//HTTP请求
	on ( 'http' , yc .loaddet ( require ( './lib/http.js' ) , true , {
		conf: {
			time: yc .time ( )
		}
	} ) .http )
	//页面生成
	on ( 'build' , yc .loaddet ( require ( './lib/build.js' ) , true ) .build )
	yc .c ( 's' , 'yccms加载完成' )
}